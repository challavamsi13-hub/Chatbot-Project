from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import nltk
from nltk.stem import WordNetLemmatizer
import pickle
import numpy as np
import json
import random
from chatbot_model import ChatbotModel

app = Flask(__name__)
CORS(app)

# Initialize the chatbot model
chatbot = ChatbotModel()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        user_message = request.json['message']
        response = chatbot.get_response(user_message)
        return jsonify({'response': response})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True) 