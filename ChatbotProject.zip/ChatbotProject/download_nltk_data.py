import nltk

# Download required NLTK data
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('omw-1.4')
print("NLTK data downloaded successfully!") 