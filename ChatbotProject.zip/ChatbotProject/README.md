# Intelligent Chatbot using Machine Learning

This project implements an intelligent chatbot using Python, Flask, NLP, and TensorFlow. The chatbot can handle user queries using natural language processing and machine learning techniques.

## Features
- Real-time automated responses
- Natural Language Processing (NLP) for understanding user queries
- Machine Learning model using TensorFlow
- Flask backend API
- Simple and intuitive web interface

## Setup Instructions

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Download NLTK data:
```bash
python -c "import nltk; nltk.download('punkt'); nltk.download('wordnet')"
```

4. Run the application:
```bash
python app.py
```

5. Open your browser and navigate to `http://localhost:5000`

## Project Structure
- `app.py`: Main Flask application
- `chatbot_model.py`: TensorFlow model implementation
- `static/`: Static files (CSS, JavaScript)
- `templates/`: HTML templates
- `training_data/`: Training data for the chatbot
- `requirements.txt`: Project dependencies

## Technologies Used
- Python
- Flask
- TensorFlow
- NLTK
- HTML/CSS/JavaScript 