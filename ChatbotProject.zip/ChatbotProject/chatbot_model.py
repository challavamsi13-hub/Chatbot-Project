import nltk
from nltk.stem import WordNetLemmatizer
import json
import pickle
import numpy as np
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import SGD
import random

class ChatbotModel:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.words = []
        self.classes = []
        self.documents = []
        self.ignore_words = ['?', '!', '.', ',']
        self.model = None
        self.intents = self.load_intents()
        self.prepare_data()
        self.train_model()

    def load_intents(self):
        return {
            "intents": [
                {
                    "tag": "greeting",
                    "patterns": ["hi", "hello", "hey", "how are you", "good day", "what's up", "greetings", "good morning", "good afternoon", "good evening", "hi there", "hello there"],
                    "responses": ["Hello! How can I help you today?", "Hi there! What's on your mind?", "Hey! I'm here to chat. What would you like to talk about?", "Greetings! How can I assist you?"]
                },
                {
                    "tag": "goodbye",
                    "patterns": ["bye", "see you later", "goodbye", "take care", "see you", "bye bye", "have a good day", "talk to you later", "good night"],
                    "responses": ["Goodbye! Have a great day!", "See you later! Take care!", "Bye! Come back if you need anything!", "Take care! It was nice chatting with you!"]
                },
                {
                    "tag": "thanks",
                    "patterns": ["thank you", "thanks", "thanks a lot", "i appreciate it", "thank you so much", "that's helpful", "thanks for helping"],
                    "responses": ["You're welcome! Happy to help!", "My pleasure! Is there anything else you'd like to discuss?", "Anytime! Feel free to ask more questions!", "Glad I could help! What else can I do for you?"]
                },
                {
                    "tag": "general_question",
                    "patterns": ["what", "how", "why", "when", "where", "who", "which", "can you", "could you", "would you", "do you", "are you", "is it", "tell me about"],
                    "responses": [
                        "That's an interesting question! Let me think about that...",
                        "I'd be happy to discuss that with you. What specific aspects interest you?",
                        "That's a great topic to explore. What would you like to know about it?",
                        "I can help you with that. Could you tell me more about what you're looking for?",
                        "That's something worth discussing. What's your perspective on it?",
                        "I'm here to help you explore that topic. What would you like to know?",
                        "That's an engaging subject. Let's talk more about it. What interests you most?",
                        "I'd love to discuss that with you. What aspects would you like to focus on?"
                    ]
                },
                {
                    "tag": "general_statement",
                    "patterns": ["i think", "i believe", "in my opinion", "i feel", "i want", "i need", "i would like", "i am", "i'm", "i have", "i had", "i will", "i can", "i could", "i should", "i must"],
                    "responses": [
                        "That's interesting! Tell me more about that.",
                        "I understand. What makes you feel that way?",
                        "That's a valid point. Would you like to elaborate?",
                        "I see. How does that affect you?",
                        "That's worth discussing. What led you to that conclusion?",
                        "I hear you. What are your thoughts on that?",
                        "That's a good perspective. Would you like to explore that further?",
                        "I appreciate you sharing that. What else would you like to discuss?"
                    ]
                },
                {
                    "tag": "clarification",
                    "patterns": ["i don't understand", "i'm confused", "can you explain", "what do you mean", "i'm not sure", "could you clarify", "i need more information", "i don't get it"],
                    "responses": [
                        "I'll try to explain that differently. What specific part would you like me to clarify?",
                        "Let me break that down for you. What aspect is unclear?",
                        "I'll help you understand better. What would you like to know more about?",
                        "Let me rephrase that. What would make it clearer for you?",
                        "I'll explain it another way. What's the main point you'd like to understand?"
                    ]
                },
                {
                    "tag": "agreement",
                    "patterns": ["yes", "yeah", "sure", "okay", "ok", "alright", "of course", "definitely", "absolutely", "right", "correct", "exactly"],
                    "responses": [
                        "Great! What would you like to explore next?",
                        "Perfect! Shall we continue our discussion?",
                        "Excellent! What else would you like to talk about?",
                        "Wonderful! How would you like to proceed?",
                        "That's good! What's on your mind now?"
                    ]
                },
                {
                    "tag": "disagreement",
                    "patterns": ["no", "nope", "not really", "i don't think so", "i disagree", "that's not right", "that's incorrect", "i don't agree", "that's not what i meant"],
                    "responses": [
                        "I understand. Could you help me understand your perspective better?",
                        "That's okay. What's your point of view on this?",
                        "I respect that. Would you like to explain your thoughts?",
                        "I see. What would you prefer to discuss instead?",
                        "That's fair. How would you approach this differently?"
                    ]
                },
                {
                    "tag": "fallback",
                    "patterns": [],
                    "responses": [
                        "I'm here to chat about anything you'd like. What's on your mind?",
                        "I'm interested in hearing your thoughts. What would you like to discuss?",
                        "I'm here to help and chat. What would you like to talk about?",
                        "I'm ready to engage in conversation. What interests you?",
                        "I'm here to listen and discuss. What's on your mind?",
                        "I'm open to discussing any topic. What would you like to explore?",
                        "I'm here to chat about whatever you'd like. What's your interest?",
                        "I'm ready to engage in any conversation. What would you like to discuss?"
                    ]
                }
            ]
        }

    def prepare_data(self):
        # Process the intents
        for intent in self.intents['intents']:
            for pattern in intent['patterns']:
                # Tokenize each word
                w = nltk.word_tokenize(pattern)
                self.words.extend(w)
                # Add to documents
                self.documents.append((w, intent['tag']))
                # Add to classes
                if intent['tag'] not in self.classes:
                    self.classes.append(intent['tag'])

        # Lemmatize and lower each word
        self.words = [self.lemmatizer.lemmatize(w.lower()) for w in self.words if w not in self.ignore_words]
        self.words = sorted(list(set(self.words)))
        self.classes = sorted(list(set(self.classes)))

    def train_model(self):
        # Create training data
        training = []
        output_empty = [0] * len(self.classes)

        # Create bag of words for each document
        for doc in self.documents:
            bag = []
            word_patterns = doc[0]
            word_patterns = [self.lemmatizer.lemmatize(word.lower()) for word in word_patterns]
            
            for word in self.words:
                bag.append(1) if word in word_patterns else bag.append(0)

            output_row = list(output_empty)
            output_row[self.classes.index(doc[1])] = 1
            training.append([bag, output_row])

        # Shuffle and convert to numpy array
        random.shuffle(training)
        training = np.array(training, dtype=object)

        # Split into features and labels
        train_x = list(training[:, 0])
        train_y = list(training[:, 1])

        # Create model
        self.model = Sequential()
        self.model.add(Dense(128, input_shape=(len(train_x[0]),), activation='relu'))
        self.model.add(Dropout(0.5))
        self.model.add(Dense(64, activation='relu'))
        self.model.add(Dropout(0.5))
        self.model.add(Dense(len(train_y[0]), activation='softmax'))

        # Compile model
        sgd = SGD(learning_rate=0.01, momentum=0.9, nesterov=True)
        self.model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

        # Train model
        self.model.fit(np.array(train_x), np.array(train_y), epochs=200, batch_size=5, verbose=1)

    def get_response(self, user_input):
        # Process user input
        user_words = nltk.word_tokenize(user_input)
        user_words = [self.lemmatizer.lemmatize(word.lower()) for word in user_words]

        # Create bag of words
        bag = [0] * len(self.words)
        for w in user_words:
            for i, word in enumerate(self.words):
                if word == w:
                    bag[i] = 1

        # Predict
        results = self.model.predict(np.array([bag]))[0]
        predicted_class_index = np.argmax(results)
        predicted_class = self.classes[predicted_class_index]

        # Get response
        for intent in self.intents['intents']:
            if intent['tag'] == predicted_class:
                return random.choice(intent['responses'])

        return "I'm here to chat about anything you'd like. What's on your mind?" 