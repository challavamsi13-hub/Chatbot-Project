import requests
from datetime import datetime
import pytz
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class APIHandler:
    def __init__(self):
        self.weather_api_key = os.getenv('WEATHER_API_KEY')
        self.news_api_key = os.getenv('NEWS_API_KEY')
        
    def get_weather(self, city):
        """Get current weather for a city"""
        try:
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={self.weather_api_key}&units=metric"
            response = requests.get(url)
            data = response.json()
            
            if response.status_code == 200:
                weather = {
                    'temperature': data['main']['temp'],
                    'description': data['weather'][0]['description'],
                    'humidity': data['main']['humidity'],
                    'wind_speed': data['wind']['speed']
                }
                return f"Current weather in {city}: {weather['temperature']}°C, {weather['description']}. Humidity: {weather['humidity']}%, Wind Speed: {weather['wind_speed']} m/s"
            else:
                return "Sorry, I couldn't fetch the weather information."
        except Exception as e:
            return f"Error fetching weather: {str(e)}"

    def get_news(self, category='general'):
        """Get latest news headlines"""
        try:
            url = f"https://newsapi.org/v2/top-headlines?category={category}&apiKey={self.news_api_key}"
            response = requests.get(url)
            data = response.json()
            
            if response.status_code == 200 and data['articles']:
                news = data['articles'][:3]  # Get top 3 headlines
                response = "Here are the latest headlines:\n"
                for i, article in enumerate(news, 1):
                    response += f"{i}. {article['title']}\n"
                return response
            else:
                return "Sorry, I couldn't fetch the news."
        except Exception as e:
            return f"Error fetching news: {str(e)}"

    def get_current_time(self, timezone='UTC'):
        """Get current time for a specific timezone"""
        try:
            tz = pytz.timezone(timezone)
            current_time = datetime.now(tz)
            return f"Current time in {timezone}: {current_time.strftime('%I:%M %p, %B %d, %Y')}"
        except Exception as e:
            return f"Error getting time: {str(e)}"

    def calculate(self, expression):
        """Perform basic calculations"""
        try:
            # Basic safety check
            allowed_chars = set('0123456789+-*/(). ')
            if not all(c in allowed_chars for c in expression):
                return "Sorry, I can only perform basic arithmetic calculations."
            
            result = eval(expression)
            return f"The result is: {result}"
        except Exception as e:
            return "Sorry, I couldn't perform that calculation."

    def convert_currency(self, amount, from_currency, to_currency):
        """Convert currency using exchange rates"""
        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{from_currency}"
            response = requests.get(url)
            data = response.json()
            
            if response.status_code == 200:
                rate = data['rates'][to_currency]
                converted_amount = amount * rate
                return f"{amount} {from_currency} = {converted_amount:.2f} {to_currency}"
            else:
                return "Sorry, I couldn't perform the currency conversion."
        except Exception as e:
            return f"Error converting currency: {str(e)}" 